let playerX = 50;
let playerY = 500;
let trash = { x: 0, y: 0, collected: false };
let score = 0;
let gameState = "INTRO"; // INTRO, INFO, MENU, INFO2, INFO3, FINAL, GAME

let backgroundImage; // Imagem da tela de introdução
let infoImage;       // Nova imagem informativa após a introdução
let menuImage;
let info2Image;
let info3Image;
let finalImage;

function preload() {
  backgroundImage = loadImage("Bem vindo(a) ao Agrinho 2025! (1).png"); // Imagem de introdução
  infoImage = loadImage("A interdependência entre campo e cidade é crucial.png"); // Nova imagem após introdução 
  menuImage = loadImage ("Os produtos do campo são fundamentais para a vida nas cidades, pois fornecem alimentos frescos e matérias-primas que são transformadas em diversos produtos industriais. Sem a produção no campo, a .png");
  info2Image = loadImage("O consumo na cidade envolve a aquisição de alimentos e produtos que são produzidos no campo. Os alimentos, como frutas, legumes, verduras, carnes e laticínios, são transportados do campo para a ci.png");
  info3Image = loadImage("O campo e a cidade são duas áreas fundamentais para a vida das pessoas. No campo, encontramos extensas áreas de terra, onde são cultivados alimentos e criados animais. Esta área é caracterizada po.png");
  finalImage = loadImage("Inserir um subtítulo.png");
  playerImg = loadImage("Design sem nome (5).png");

}

function setup() {
  createCanvas(800, 600);
}

function draw() {
  if (gameState === "INTRO") {
    drawIntro();
  } else if (gameState === "INFO") {
    drawInfo(); // Nova tela informativa
  } else if (gameState === "MENU") {
    drawMenu();
  } else if (gameState === "INFO2") {
    drawInfo2(); 
  } else if (gameState === "INFO3") {
    drawInfo3(); 
   } else if (gameState === "FINAL") {
    drawfinal();
   } else if (gameState === "GAME") {
   drawGame(); // chama o jogo
  }
}

function keyPressed() {
  if (gameState === "INTRO" && keyCode === 32) {
    gameState = "INFO"; // Vai para a tela de informações
  } else if (gameState === "INFO" && keyCode === 32) {
    gameState = "MENU"; // Vai para o menu
  } else if (gameState === "MENU" && keyCode === 32) {
    gameState = "INFO2"; 
  } else if (gameState === "INFO2" && keyCode === 32) {
     gameState = "INFO3"; 
  }  else if (gameState === "INFO3" && keyCode === 32) {
   gameState = "FINAL"; 
  }  else if (gameState === "FINAL" && keyCode === 32) {
   gameState = "GAME"; // Começa o jogo aqui
   
}
}
//introdução
function drawIntro() {
  background(0);
  image(backgroundImage, 0, 0, width, height);
  fill("black");
  textSize(57);
  textAlign(CENTER, CENTER);
  text("𝐁𝐞𝐦 𝐯𝐢𝐧𝐝𝐨(𝐚) 𝐚𝐨 𝐀𝐠𝐫𝐢𝐧𝐡𝐨 \n 𝟐𝟎𝟐𝟓!", width / 2, height / 4);
  textSize(30);
  text("𝐌𝐞𝐮 𝐧𝐨𝐦𝐞 𝐞́ 𝐈𝐬𝐚𝐛𝐞𝐥𝐥𝐲 𝐞 𝐡𝐨𝐣𝐞 𝐯𝐢𝐦 𝐟𝐚𝐥𝐚𝐫 𝐮𝐦\n 𝐩𝐨𝐮𝐜𝐨 𝐬𝐨𝐛𝐫𝐞 𝐚 𝐢𝐦𝐩𝐨𝐫𝐭𝐚̂𝐧𝐜𝐢𝐚 𝐝𝐚 𝐮𝐧𝐢𝐚̃𝐨 𝐝𝐨\n 𝐜𝐚𝐦𝐩𝐨 𝐞 𝐝𝐚 𝐜𝐢𝐝𝐚𝐝𝐞. 𝐕𝐚𝐦𝐨𝐬 𝐥𝐚́!", width / 2, height / 2);
  textSize(16);
  text("Pressione ESPAÇO para continuar", width / 2, height * 3 / 4);
}

function drawInfo() {
  background(255);
  image(infoImage, 0, 0, width, height);
  fill("black");
  textSize(50);
  textAlign(CENTER, CENTER);
  text("𝘼 𝙞𝙣𝙩𝙚𝙧𝙙𝙚𝙥𝙚𝙣𝙙𝙚̂𝙣𝙘𝙞𝙖 𝙚𝙣𝙩𝙧𝙚\n 𝙘𝙖𝙢𝙥𝙤 𝙚 𝙘𝙞𝙙𝙖𝙙𝙚 𝙚́ 𝙘𝙧𝙪𝙘𝙞𝙖𝙡:", height / 1.5 , height /6 );
  textSize(30);
  text("𝗘𝗻𝗾𝘂𝗮𝗻𝘁𝗼 𝗼 𝗰𝗮𝗺𝗽𝗼 𝗳𝗼𝗿𝗻𝗲𝗰𝗲 𝗼𝘀 𝗮𝗹𝗶𝗺𝗲𝗻𝘁𝗼𝘀\n 𝗲 𝗺𝗮𝘁𝗲́𝗿𝗶𝗮𝘀-𝗽𝗿𝗶𝗺𝗮𝘀 𝗻𝗲𝗰𝗲𝘀𝘀𝗮́𝗿𝗶𝗮𝘀 𝗽𝗮𝗿𝗮\n 𝗮 𝘀𝗼𝗯𝗿𝗲𝘃𝗶𝘃𝗲̂𝗻𝗰𝗶𝗮 𝗱𝗮𝘀 𝗰𝗶𝗱𝗮𝗱𝗲𝘀, 𝗲𝘀𝘁𝗮𝘀 𝗼𝗳𝗲𝗿𝗲𝗰𝗲𝗺 \n 𝗺𝗲𝗿𝗰𝗮𝗱𝗼 𝗰𝗼𝗻𝘀𝘂𝗺𝗶𝗱𝗼𝗿, 𝗯𝗲𝗻𝘀 𝗲 𝘀𝗲𝗿𝘃𝗶𝗰̧𝗼𝘀 𝗾𝘂𝗲 𝗻𝗮̃𝗼\n 𝘀𝗮̃𝗼 𝗽𝗿𝗼𝗱𝘂𝘇𝗶𝗱𝗼𝘀 𝗻𝗼 𝗰𝗮𝗺𝗽𝗼. 𝗗𝗲𝘀𝘀𝗮 𝗳𝗼𝗿𝗺𝗮,\n 𝗮 𝗿𝗲𝗹𝗮𝗰̧𝗮̃𝗼 𝗲𝗻𝘁𝗿𝗲 𝗰𝗮𝗺𝗽𝗼 𝗲 𝗰𝗶𝗱𝗮𝗱𝗲 𝗲́ 𝗲𝘀𝘀𝗲𝗻𝗰𝗶𝗮𝗹\n 𝗽𝗮𝗿𝗮 𝗮 𝗺𝗮𝗻𝘂𝘁𝗲𝗻𝗰̧𝗮̃𝗼 𝗱𝗼 𝗯𝗲𝗺-𝗲𝘀𝘁𝗮𝗿 𝗲 \n 𝗱𝗮 𝗾𝘂𝗮𝗹𝗶𝗱𝗮𝗱𝗲 𝗱𝗲 𝘃𝗶𝗱𝗮 𝗱𝗮𝘀 𝗽𝗲𝘀𝘀𝗼𝗮𝘀.", height / 1.5, height / 1.7);
  fill(0);
  textAlign(CENTER);
  textSize(20);
  text("Pressione ESPAÇO para avançar", width / 2, height / 1.1);
}

function drawMenu() {
   background(255);
  image(menuImage, 0, 0, width, height);
  fill("white");
  textAlign(CENTER, CENTER);
  textSize(40);
  text("𝑨𝒍𝒊𝒎𝒆𝒏𝒕𝒐𝒔", width / 2, 100);
  textSize(29);
  text("𝗔 𝗽𝗿𝗼𝗱𝘂𝗰̧𝗮̃𝗼 𝗻𝗼 𝗰𝗮𝗺𝗽𝗼 𝗲́ 𝗳𝗼𝗰𝗮𝗱𝗮 \n 𝗽𝗿𝗶𝗻𝗰𝗶𝗽𝗮𝗹𝗺𝗲𝗻𝘁𝗲 𝗻𝗮 𝗮𝗴𝗿𝗶𝗰𝘂𝗹𝘁𝘂𝗿𝗮 𝗲 𝗻𝗮 𝗽𝗲𝗰𝘂𝗮́𝗿𝗶𝗮.\n 𝗢𝘀 𝗽𝗿𝗼𝗱𝘂𝘁𝗼𝘀 𝗱𝗼 𝗰𝗮𝗺𝗽𝗼 𝘀𝗮̃𝗼 𝗳𝘂𝗻𝗱𝗮𝗺𝗲𝗻𝘁𝗮𝗶𝘀\n 𝗽𝗮𝗿𝗮 𝗮 𝘃𝗶𝗱𝗮 𝗻𝗮𝘀 𝗰𝗶𝗱𝗮𝗱𝗲𝘀, 𝗽𝗼𝗶𝘀 𝗳𝗼𝗿𝗻𝗲𝗰𝗲𝗺\n 𝗮𝗹𝗶𝗺𝗲𝗻𝘁𝗼𝘀 𝗳𝗿𝗲𝘀𝗰𝗼𝘀 𝗲 𝗺𝗮𝘁𝗲́𝗿𝗶𝗮𝘀-𝗽𝗿𝗶𝗺𝗮𝘀 𝗾𝘂𝗲 𝘀𝗮̃𝗼 \n 𝘁𝗿𝗮𝗻𝘀𝗳𝗼𝗿𝗺𝗮𝗱𝗮𝘀 𝗲𝗺 𝗱𝗶𝘃𝗲𝗿𝘀𝗼𝘀 𝗽𝗿𝗼𝗱𝘂𝘁𝗼𝘀 𝗶𝗻𝗱𝘂𝘀𝘁𝗿𝗶𝗮𝗶𝘀.\n 𝗦𝗲𝗺 𝗮 𝗽𝗿𝗼𝗱𝘂𝗰̧𝗮̃𝗼 𝗻𝗼 𝗰𝗮𝗺𝗽𝗼, 𝗮 𝗼𝗳𝗲𝗿𝘁𝗮 𝗱𝗲 𝗮𝗹𝗶𝗺𝗲𝗻𝘁𝗼𝘀\n 𝗻𝗮𝘀 𝗰𝗶𝗱𝗮𝗱𝗲𝘀 𝘀𝗲𝗿𝗶𝗮 𝗶𝗻𝘀𝘂𝗳𝗶𝗰𝗶𝗲𝗻𝘁𝗲 𝗽𝗮𝗿𝗮 𝗮𝘁𝗲𝗻𝗱𝗲𝗿\n 𝗮̀ 𝗱𝗲𝗺𝗮𝗻𝗱𝗮 𝗱𝗮 𝗽𝗼𝗽𝘂𝗹𝗮𝗰̧𝗮̃𝗼 𝘂𝗿𝗯𝗮𝗻𝗮.", height / 1.5, height / 1.8);
  textSize(20);
  text("Pressione ESPAÇO para avançar", width / 2, height - 50);
}

function drawInfo2() {
   background(255);
  image(info2Image, 0, 0, width, height);
  fill("black");
  textAlign(CENTER, CENTER);
  textSize(57);
  text("𝑪𝒐𝒏𝒔𝒖𝒎𝒐", width / 2, 100);
  textSize(30);
  text("𝗢 𝗰𝗼𝗻𝘀𝘂𝗺𝗼 𝗻𝗮 𝗰𝗶𝗱𝗮𝗱𝗲 𝗲𝗻𝘃𝗼𝗹𝘃𝗲 𝗮 𝗮𝗾𝘂𝗶𝘀𝗶𝗰̧𝗮̃𝗼 𝗱𝗲\n 𝗮𝗹𝗶𝗺𝗲𝗻𝘁𝗼𝘀 𝗲 𝗽𝗿𝗼𝗱𝘂𝘁𝗼𝘀 𝗾𝘂𝗲 𝘀𝗮̃𝗼 𝗽𝗿𝗼𝗱𝘂𝘇𝗶𝗱𝗼𝘀 𝗻𝗼 𝗰𝗮𝗺𝗽𝗼.\n 𝗢𝘀 𝗮𝗹𝗶𝗺𝗲𝗻𝘁𝗼𝘀, 𝗰𝗼𝗺𝗼 𝗳𝗿𝘂𝘁𝗮𝘀, 𝗹𝗲𝗴𝘂𝗺𝗲𝘀, 𝘃𝗲𝗿𝗱𝘂𝗿𝗮𝘀, \n 𝗰𝗮𝗿𝗻𝗲𝘀 𝗲 𝗹𝗮𝘁𝗶𝗰𝗶́𝗻𝗶𝗼𝘀, 𝘀𝗮̃𝗼 𝘁𝗿𝗮𝗻𝘀𝗽𝗼𝗿𝘁𝗮𝗱𝗼𝘀 𝗱𝗼 𝗰𝗮𝗺𝗽𝗼\n 𝗽𝗮𝗿𝗮 𝗮 𝗰𝗶𝗱𝗮𝗱𝗲 𝗽𝗼𝗿 𝗺𝗲𝗶𝗼 𝗱𝗲 𝗰𝗮𝗺𝗶𝗻𝗵𝗼̃𝗲𝘀 𝗲 𝗼𝘂𝘁𝗿𝗼𝘀 𝗺𝗲𝗶𝗼𝘀\n 𝗱𝗲 𝘁𝗿𝗮𝗻𝘀𝗽𝗼𝗿𝘁𝗲. 𝗔 𝗹𝗼𝗴𝗶́𝘀𝘁𝗶𝗰𝗮 𝗱𝗲 𝘁𝗿𝗮𝗻𝘀𝗽𝗼𝗿𝘁𝗲\n 𝗲 𝗮𝗿𝗺𝗮𝘇𝗲𝗻𝗮𝗺𝗲𝗻𝘁𝗼 𝗲́ 𝗰𝗿𝘂𝗰𝗶𝗮𝗹 𝗽𝗮𝗿𝗮 𝗴𝗮𝗿𝗮𝗻𝘁𝗶𝗿 𝗾𝘂𝗲 𝗼𝘀 \n 𝗽𝗿𝗼𝗱𝘂𝘁𝗼𝘀 𝗰𝗵𝗲𝗴𝘂𝗲𝗺 𝗳𝗿𝗲𝘀𝗰𝗼𝘀 𝗲 𝗲𝗺 𝗯𝗼𝗮𝘀 𝗰𝗼𝗻𝗱𝗶𝗰̧𝗼̃𝗲𝘀\n 𝗮𝗼𝘀 𝗰𝗼𝗻𝘀𝘂𝗺𝗶𝗱𝗼𝗿𝗲𝘀 𝘂𝗿𝗯𝗮𝗻𝗼𝘀.", height / 1.5, height / 1.7);
  textSize(20);
  text("Pressione ESPAÇO para avançar", width / 2, height - 50);
}
function drawInfo3() {
   background(255);
  image(info3Image, 0, 0, width, height);
  fill("black");
  textAlign(CENTER, CENTER);
  textSize(57);
  text("𝑪𝒂𝒎𝒑𝒐 𝒆 𝒄𝒊𝒅𝒂𝒅𝒆", width / 2, 100);
  textSize(30);
  text("𝗣𝗼𝗿𝘁𝗮𝗻𝘁𝗼, 𝗼 𝗰𝗮𝗺𝗽𝗼 𝗲 𝗮 𝗰𝗶𝗱𝗮𝗱𝗲 𝘀𝗮̃𝗼 𝗱𝘂𝗮𝘀 \n 𝗮́𝗿𝗲𝗮𝘀 𝗳𝘂𝗻𝗱𝗮𝗺𝗲𝗻𝘁𝗮𝗶𝘀 𝗽𝗮𝗿𝗮 𝗮 𝘃𝗶𝗱𝗮 𝗱𝗮𝘀 𝗽𝗲𝘀𝘀𝗼𝗮𝘀. \n 𝗡𝗼 𝗰𝗮𝗺𝗽𝗼, 𝗲𝗻𝗰𝗼𝗻𝘁𝗿𝗮𝗺𝗼𝘀 𝗲𝘅𝘁𝗲𝗻𝘀𝗮𝘀 𝗮́𝗿𝗲𝗮𝘀 𝗱𝗲 𝘁𝗲𝗿𝗿𝗮,\n 𝗼𝗻𝗱𝗲 𝘀𝗮̃𝗼 𝗰𝘂𝗹𝘁𝗶𝘃𝗮𝗱𝗼𝘀 𝗮𝗹𝗶𝗺𝗲𝗻𝘁𝗼𝘀 𝗲 𝗰𝗿𝗶𝗮𝗱𝗼𝘀 𝗮𝗻𝗶𝗺𝗮𝗶𝘀.\n 𝗘𝘀𝘁𝗮 𝗮́𝗿𝗲𝗮 𝗲́ 𝗰𝗮𝗿𝗮𝗰𝘁𝗲𝗿𝗶𝘇𝗮𝗱𝗮 𝗽𝗼𝗿 𝘁𝗲𝗿 𝘂𝗺𝗮 𝗺𝗲𝗻𝗼𝗿 𝗱𝗲𝗻𝘀𝗶𝗱𝗮𝗱𝗲\n 𝗽𝗼𝗽𝘂𝗹𝗮𝗰𝗶𝗼𝗻𝗮𝗹 𝗲 𝘂𝗺𝗮 𝗳𝗼𝗿𝘁𝗲 𝗹𝗶𝗴𝗮𝗰̧𝗮̃𝗼 𝗰𝗼𝗺\n 𝗮𝘁𝗶𝘃𝗶𝗱𝗮𝗱𝗲𝘀 𝗮𝗴𝗿𝗶́𝗰𝗼𝗹𝗮𝘀 𝗲 𝗽𝗲𝗰𝘂𝗮́𝗿𝗶𝗮𝘀. 𝗣𝗼𝗿 𝗼𝘂𝘁𝗿𝗼 𝗹𝗮𝗱𝗼, 𝗮𝘀\n 𝗰𝗶𝗱𝗮𝗱𝗲𝘀 𝘀𝗮̃𝗼 𝗮𝗺𝗯𝗶𝗲𝗻𝘁𝗲𝘀 𝗰𝗼𝗺 𝗺𝗮𝗶𝗼𝗿 𝗰𝗼𝗻𝗰𝗲𝗻𝘁𝗿𝗮𝗰̧𝗮̃𝗼 𝗱𝗲\n 𝗽𝗲𝘀𝘀𝗼𝗮𝘀, 𝗺𝘂𝗶𝘁𝗮𝘀 𝗰𝗼𝗻𝘀𝘁𝗿𝘂𝗰̧𝗼̃𝗲𝘀 𝗲 𝘂𝗺𝗮 𝘃𝗮𝗿𝗶𝗲𝗱𝗮𝗱𝗲 𝗱𝗲 \n 𝗰𝗼𝗺𝗲́𝗿𝗰𝗶𝗼𝘀 𝗲 𝘀𝗲𝗿𝘃𝗶𝗰̧𝗼𝘀.", height / 1.5, height / 1.7);
  textSize(20);
  text("Pressione ESPAÇO para avançar", width / 2, height - 40);
}
function drawfinal() {
   background(255);
  image(finalImage, 0, 0, width, height);
  fill("white");
  textAlign(CENTER, CENTER);
  textSize(40);
  text("𝐄 𝐞𝐬𝐬𝐚 𝐟𝐨𝐢 𝐮𝐦 𝐩𝐨𝐮𝐜𝐨 𝐝𝐚 𝐦𝐢𝐧𝐡𝐚\n 𝐞𝐱𝐩𝐥𝐢𝐜𝐚𝐜̧𝐚̃𝐨 𝐬𝐨𝐛𝐫𝐞 𝐚 𝐢𝐧𝐭𝐞𝐫𝐩𝐞𝐧𝐝𝐞̂𝐧𝐜𝐢𝐚 𝐫𝐮𝐫𝐚𝐥 \n𝐞 𝐮𝐫𝐛𝐚𝐧𝐚, 𝐞𝐬𝐩𝐞𝐫𝐨 𝐪𝐮𝐞 𝐭𝐞𝐧𝐡𝐚 𝐠𝐨𝐬𝐭𝐚𝐝𝐨!", width / 2, 150);
    textSize(37);
  text("𝐄 𝐚𝐪𝐮𝐢 𝐭𝐞𝐧𝐡𝐨 𝐮𝐦 𝐣𝐨𝐠𝐨 𝐩𝐚𝐫𝐚 𝐯𝐨𝐜𝐞̂ 𝐬𝐞 𝐝𝐢𝐯𝐞𝐫𝐭𝐢𝐫!", height / 1.5, height / 2);
   textSize(37);
  text("𝗨𝘀𝗲 𝗮𝘀 𝘀𝗲𝘁𝗮𝘀 𝗱𝗶𝗿𝗲𝗶𝘁𝗮 𝗲 𝗲𝘀𝗾𝘂𝗲𝗿𝗱𝗮 𝗽𝗮𝗿𝗮\n 𝗰𝗼𝗹𝗲𝘁𝗮𝗿 𝗮𝘀 𝗳𝗿𝘂𝘁𝗮𝘀, 𝗹𝗲𝗴𝘂𝗺𝗲𝘀 𝗲 𝘃𝗲𝗿𝗱𝘂𝗿𝗮𝘀\n 𝗾𝘂𝗲 𝗲𝘀𝘁𝗮̃𝗼 𝗰𝗮𝗶𝗻𝗱𝗼. 𝗢𝗯𝗿𝗶𝗴𝗮𝗱𝗮 𝗽𝗼𝗿 𝗰𝗵𝗲𝗴𝗮𝗿 \n 𝗮𝘁𝗲́ 𝗮𝗾𝘂𝗶!", height / 1.5, height / 1.4);
  textSize(20);
  text("Pressione ESPAÇO para começar o jogo", width / 2, height - 40);
}

let playerWidth = 50;
let playerHeight = 100;
let playerImg;
let emojis = ["🍎", "🍌", "🌽", "🍓", "🥔", "🥕", "🍉", "🍅", "🥦", "🍍"];
let currentEmoji = "";


function setup() {
  createCanvas(800, 600);
  resetTrash();
  textSize(32);
  textAlign(CENTER, CENTER);
}

function drawGame() {
  background(135, 206, 235);

  // Movimento suave com teclas
  if (keyIsDown(RIGHT_ARROW)) {
    playerX += 10;
    if (playerX + playerWidth > width) playerX = width - playerWidth;
  }
  if (keyIsDown(LEFT_ARROW)) {
    playerX -= 10;
    if (playerX < 0) playerX = 0;
  }

  // Chão
  fill(34, 139, 34);
  rect(0, height - 100, width, 100);

  // Árvores
  drawTree(100, height - 150);
  drawTree(200, height - 150);
  drawTree(300, height - 150);

  // Prédios
  drawBuilding(500, height - 200, 100, 200);
  drawBuilding(650, height - 250, 80, 250);

  // Personagem
  image(playerImg, playerX, playerY, playerWidth, playerHeight);

  // Emoji caindo
  if (!trash.collected) {
    textSize(32);
    text(currentEmoji, trash.x, trash.y);
    trash.y += 1;
  }

  // Reiniciar se sair da tela
  if (trash.y > height) {
    resetTrash();
  }

  // Colisão com personagem
  if (!trash.collected &&
    trash.y >= playerY && trash.y <= playerY + playerHeight &&
    trash.x >= playerX && trash.x <= playerX + playerWidth) {
    trash.collected = true;
    score++;
    resetTrash();
  }

  // Pontuação
  fill(0);
  textSize(24);
  textAlign(LEFT, TOP);
  text("Pontuação: " + score, 10, 10);
}

function resetTrash() {
  trash.x = random(50, width - 50);
  trash.y = 0;
  trash.collected = false;
  currentEmoji = random(emojis);
}

function drawTree(x, y) {
  fill(139, 69, 19);
  rect(x, y, 20, 50);
  fill(0, 128, 0);
  ellipse(x + 10, y - 20, 60, 60);
}

function drawBuilding(x, y, w, h) {
  fill(169, 169, 169);
  rect(x, y, w, h);
  fill(255);
  for (let i = 0; i < w; i += 20) {
    for (let j = 0; j < h; j += 40) {
      rect(x + i + 5, y + j + 5, 10, 20);
    }
  }
}
